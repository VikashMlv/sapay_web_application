import { Component } from '@angular/core';

@Component({
  selector: 'app-fixed',
  imports: [],
  templateUrl: './fixed.component.html',
  styleUrl: './fixed.component.scss'
})
export class FixedComponent {

}
