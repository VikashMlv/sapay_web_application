import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './features/home/home.component';
import { ContactComponent } from './features/contact/contact.component';
import { AboutComponent } from './features/about/about.component';
import { ProductsComponent } from './features/products/products.component';


const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },  // Redirect to Home page on app load
  { path: '/', component: HomeComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'about-us', component: AboutComponent },
  { path: 'product', component: ProductsComponent },
  { path: 'home', component: HomeComponent },
  { path: '**', redirectTo: 'home' }
  // You can add more routes here for additional pages or components
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
