import { Component } from '@angular/core';
import { FaqComponent } from '../../shared/components/faq/faq.component';

@Component({
  selector: 'app-contact',
  imports: [FaqComponent],
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.scss'
})
export class ContactComponent {

  emailAddress:string = 'sa.store02@gmail.com'

   // Sample data for FAQs
   questions = [
    {
      text: 'How much will my website cost?',
      answer: 'The cost of your website depends on its features and complexity.',
      open: false,
    },
    {
      text: 'Can I update the website myself after it’s built?',
      answer: 'Yes, you can update it yourself if we build it with a CMS like WordPress.',
      open: false,
    },
    {
      text: 'Will my website be secure?',
      answer: 'Yes, we follow industry best practices to ensure your website is secure.',
      open: false,
    },
  ];

  toggleAnswer(index: number): void {
    this.questions[index].open = !this.questions[index].open;
  }

  
  currentSlide = 0;
  totalSlides = 3;  // Number of slides (adjust based on your slider count)
  slideInterval: any;

  sportsAndGames: any;


  constructor() { }

  ngOnInit(): void {

 // Automatically change slides every 3 seconds (3000 ms)
 this.slideInterval = setInterval(() => {
  this.nextSlide();
}, 3000);
   
    const carousels = document.querySelectorAll(".carousel") as NodeListOf<Element>
    console.log(carousels)
    setInterval(() => {
      carousels.forEach((item, index) => {
        var itemWidth = item.querySelector("div")?.clientWidth;
        if (itemWidth) {
          if (item.scrollWidth - itemWidth > item.scrollLeft + itemWidth) {
            item.scrollTo({ left: item.scrollLeft + itemWidth, top: 0, behavior: "smooth" })
          }
          else {
            item.scrollTo({ left: 0, top: 0, behavior: "smooth" })
          }
        }
      })
    }, 5000)

  }


  ngOnDestroy() {
    // Clean up the interval when the component is destroyed
    if (this.slideInterval) {
      clearInterval(this.slideInterval);
    }
  }


   nextSlide() {
    this.currentSlide = (this.currentSlide + 1) % this.totalSlides;
    this.updateSliderPosition();
  }

  prevSlide() {
    this.currentSlide = (this.currentSlide - 1 + this.totalSlides) % this.totalSlides;
    this.updateSliderPosition();
  }

  updateSliderPosition() {
    const slider = document.querySelector('.slider') as HTMLElement;
    slider.style.transform = `translateX(-${this.currentSlide * 100}%)`;
  }

}
