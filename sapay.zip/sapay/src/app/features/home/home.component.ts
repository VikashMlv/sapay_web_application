import { CommonModule } from '@angular/common';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CarouselModule } from 'ngx-bootstrap/carousel';

@Component({
  selector: 'app-home',
  imports: [CarouselModule, CommonModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class HomeComponent {

  currentSlide = 0;
  totalSlides = 3;  // Number of slides (adjust based on your slider count)
  slideInterval: any;

  sportsAndGames: any;


  constructor() { }

  ngOnInit(): void {

 // Automatically change slides every 3 seconds (3000 ms)
 this.slideInterval = setInterval(() => {
  this.nextSlide();
}, 3000);
    this.sportsAndGames = {
      loop: true,
      margin: 10,
      nav: true,
      items: 1,
      autoplay: true,
      autoplayTimeout: 5000,
      autoplayHoverPause: true,
      responsive: {
        0: {
          items: 1
        },
        600: {
          items: 2
        },
        1000: {
          items: 3
        }
      }
    };
    const carousels = document.querySelectorAll(".carousel") as NodeListOf<Element>
    console.log(carousels)
    setInterval(() => {
      carousels.forEach((item, index) => {
        var itemWidth = item.querySelector("div")?.clientWidth;
        if (itemWidth) {
          if (item.scrollWidth - itemWidth > item.scrollLeft + itemWidth) {
            item.scrollTo({ left: item.scrollLeft + itemWidth, top: 0, behavior: "smooth" })
          }
          else {
            item.scrollTo({ left: 0, top: 0, behavior: "smooth" })
          }
        }
      })
    }, 5000)

  }


  ngOnDestroy() {
    // Clean up the interval when the component is destroyed
    if (this.slideInterval) {
      clearInterval(this.slideInterval);
    }
  }


   nextSlide() {
    this.currentSlide = (this.currentSlide + 1) % this.totalSlides;
    this.updateSliderPosition();
  }

  prevSlide() {
    this.currentSlide = (this.currentSlide - 1 + this.totalSlides) % this.totalSlides;
    this.updateSliderPosition();
  }

  updateSliderPosition() {
    const slider = document.querySelector('.slider') as HTMLElement;
    slider.style.transform = `translateX(-${this.currentSlide * 100}%)`;
  }

  
}
